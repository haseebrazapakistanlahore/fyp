<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Password;
use Auth;
use Hash;
use Illuminate\Support\Str;

class ProfessionalResetPasswordController extends Controller
{
    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/reset-success';

     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:api');
    }
    public function showResetForm(Request $request, $token = null) {
        return view('user.professionalRestPasswordForm')
            ->with(['token' => $token, 'email' => $request->email]
            );
    }


    //defining which guard to use in our case, it's the tourist guard
    protected function guard()
    {
        return Auth::guard('professional');
    }

    //defining our password broker function
    protected function broker() {
        return Password::broker('professionals');
    }

    protected function resetPassword($user, $password)
    {
        $user->password = Hash::make($password);
        
        $user->setRememberToken(Str::random(60));
        
        $user->is_deleted = 0;

        $user->save();
 
        // event(new PasswordReset($user));
 
        // $this->guard()->login($user);
    }
}
